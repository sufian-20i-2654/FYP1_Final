export {default as Footer} from "./footer/Footer";
export {default as Header} from "./header/Header";
export {default as WhatGPT3} from "./whatTalkTales/WhatTalkTales";
export {default as Login} from "./login/Login";
export {default as SignUp} from "./signup/SignUp";